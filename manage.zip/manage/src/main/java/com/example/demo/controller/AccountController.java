package com.example.demo.controller;

import com.example.demo.entity.Account;
import com.example.demo.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private AccountService accountService;

    // 登录页面
    @GetMapping("/login")
    public String loginPage() {
        return "account/login";
    }

    // 注册页面
    @GetMapping("/register")
    public String registerPage() {
        return "account/register";
    }

    // 注册处理
    @PostMapping("/register")
    public String register(@RequestParam String username, @RequestParam String password) {
        Account account = new Account();
        account.setUsername(username);
        account.setPassword(password);
        accountService.save(account);
        return "redirect:/account/login";  // 注册成功后跳转到登录页面
    }

    // 登录处理
    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        Account account = accountService.findByUsername(username);

        if (account != null && account.getPassword().equals(password)) {
            // 登录成功后跳转到账户列表页面
            return "redirect:/account/list";
        } else {
            // 登录失败，返回登录页面并显示错误信息
            model.addAttribute("error", "Invalid credentials");
            return "account/login";
        }
    }

    // 账户列表页面
    @GetMapping("/list")
    public String accountList(Model model) {
        model.addAttribute("accounts", accountService.findAll());
        return "account/list";
    }
}

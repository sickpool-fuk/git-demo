package com.example.demo.controller;

import com.example.demo.entity.SciGroup;
import com.example.demo.service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/group")
public class GroupController {

    @Autowired
    private GroupService groupService;

    // 小组列表页面
    @GetMapping("/list")
    public String listGroups(Model model) {
        model.addAttribute("groups", groupService.findAll());
        return "group/list";
    }

    // 添加/编辑小组页面
    @GetMapping("/form")
    public String showForm(@RequestParam(value = "id", required = false) Long id, Model model) {
        if (id != null) {
            model.addAttribute("group", groupService.findById(id));
        } else {
            model.addAttribute("group", new SciGroup());
        }
        return "group/form";
    }

    // 提交小组表单
    @PostMapping("/form")
    public String saveGroup(SciGroup group) {
        groupService.save(group);
        return "redirect:/group/list";
    }
}

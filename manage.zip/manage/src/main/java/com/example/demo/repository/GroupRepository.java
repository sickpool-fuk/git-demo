package com.example.demo.repository;

import com.example.demo.entity.SciGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GroupRepository extends JpaRepository<SciGroup, Long> {
}

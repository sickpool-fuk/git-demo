package com.example.demo.service;

import com.example.demo.entity.Account;
import com.example.demo.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    // 保存账户
    public Account save(Account account) {
        return accountRepository.save(account);
    }

    // 根据用户名查找账户
    public Account findByUsername(String username) {
        return accountRepository.findByUsername(username);
    }

    // 查找所有账户
    public List<Account> findAll() {
        return accountRepository.findAll();
    }

    // 根据 ID 删除账户
    public void delete(Long id) {
        accountRepository.deleteById(id);
    }
}

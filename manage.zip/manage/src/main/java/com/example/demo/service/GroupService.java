package com.example.demo.service;

import com.example.demo.entity.SciGroup;
import com.example.demo.repository.GroupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupService {

    @Autowired
    private GroupRepository groupRepository;

    // 保存小组
    public SciGroup save(SciGroup group) {
        return groupRepository.save(group);
    }

    // 查找所有小组
    public List<SciGroup> findAll() {
        return groupRepository.findAll();
    }

    // 根据 ID 查找小组
    public SciGroup findById(Long id) {
        return groupRepository.findById(id).orElse(null);
    }

    // 根据 ID 删除小组
    public void delete(Long id) {
        groupRepository.deleteById(id);
    }
}

package com.example.demo.service;

import com.example.demo.entity.Member;
import com.example.demo.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MemberService {

    @Autowired
    private MemberRepository memberRepository;

    // 查找所有成员
    public List<Member> findAll() {
        return memberRepository.findAll();
    }

    // 根据ID查找成员
    public Optional<Member> findById(Long id) {
        return memberRepository.findById(id);
    }

    // 保存成员
    public Member save(Member member) {
        return memberRepository.save(member);
    }

    // 删除成员
    public void deleteById(Long id) {
        memberRepository.deleteById(id);
    }
}
